# Handoff: Character sheet top bar restyle (option 1a)

## Overview
An appearance-only restyle of the top bar on the D&D character sheet app. The sheet title moves to the top of the visual stack, and the account/character controls drop into a quieter utility rail beneath it. **No functional changes**: the same six controls exist, with the same handlers and the same behavior as today.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype of the intended look, not production code to paste in. Recreate this styling inside the app's existing environment and patterns (templates, CSS/framework, class conventions). `topbar.html` / `topbar.css` are provided as a close-to-drop-in starting point, but the class names and structure should be adapted to whatever the codebase already uses.

## Fidelity
**High fidelity.** Colors, type, spacing, and radii below are final. Match them.

## Screen
**Name:** Character sheet — top bar
**Purpose:** Identify the sheet being viewed; switch/create/save/delete characters; manage session.

**Layout:** Full-width header, two stacked rows, 3px solid `#1d1a17` border, 14px top corner radius, `overflow: hidden`.

1. **Banner row** — `padding: 26px 32px 20px`, background `linear-gradient(180deg,#8f8b83,#7b7770)`, 3px bottom border `#1d1a17`. Column flex, centered, `gap: 4px`.
   - `h1` "Dungeons & Dragons" — Cinzel 700, 44px, `letter-spacing: .03em`, `#c0322a`, `text-shadow: 0 2px 0 rgba(0,0,0,.28)`, `white-space: nowrap`.
   - Sheet link "Gerome's Spellbook" (the existing spellbook link, character-name driven) — IM Fell English, 17px, uppercase, `letter-spacing: .16em`, `#f2e4cd`, underlined; hover `#fff`.

2. **Utility rail** — `padding: 12px 24px`, background `#f1e3ca`, 3px bottom border `#1d1a17`. Row flex, `align-items: center`, `gap: 12px`.
   - Left group (`margin-right: auto`, `gap: 10px`): 30px circular avatar (initials, `#c0322a` fill, `#fbeeda` text, 12px/700); user name 14px `#3b332c`; "Sign out" as a 13px underlined text button `#8a7e70`. This replaces the old "Signed in as …" sentence — same sign-out action.
   - Character `<select>`: 14px, `padding: 8px 34px 8px 14px`, 2px `#1d1a17` border, 8px radius, `#fff9ef` fill, native arrow suppressed with `appearance:none` and a ▼ drawn via `::after`.
   - "New Character" — outline button: 2px `#1d1a17`, `#fff9ef` fill, `#2c2622` text, `padding: 8px 16px`.
   - "Save Now" — primary: `#c0322a` fill, `#fff4e3` text, 600 weight, `padding: 8px 18px`, 2px `#1d1a17` border. Hover `#a8231c`.
   - "Delete" — ghost: transparent, 2px `#b8ada0` border, `#7a6f64` text, `padding: 8px 14px`. Hover turns border and text `#c0322a`.

All labels carry `white-space: nowrap` and `flex-shrink: 0`; only the left account group shrinks.

## Interactions & Behavior
Unchanged from the current implementation — wire the existing handlers to the same ids:
- `#signOutBtn` → sign out
- `#characterSelect` → load selected character (keep existing options/values and the "-- Select a character --" placeholder)
- `#newCharacterBtn`, `#saveNowBtn`, `#deleteBtn` → existing create / save / delete
- Hover transitions: `120ms ease` on background, color, border-color. Focus-visible: 2px `#c0322a` outline, 2px offset.
- Responsive: below ~900px let the rail wrap (`flex-wrap: wrap`) rather than shrinking labels; the banner title can drop to ~32px.

## State Management
No new state. Existing state only: signed-in user (name/initials), character list + selected character, unsaved-changes flag if the app already has one. The title line shows the app name; the link below shows the current sheet name.

## Design Tokens
- Ink `#1d1a17`, ink-soft `#2c2622`
- Parchment `#fbeeda`, rail `#f1e3ca`, control fill `#fff9ef`
- Red `#c0322a` (hover `#a8231c`), red ink `#fff4e3`
- Stone gradient `#8f8b83` → `#7b7770`, cream text `#f2e4cd`
- Muted `#8a7e70`, `#7a6f64`, hairline `#b8ada0`
- Spacing: 4 / 10 / 12 / 16 / 24 / 26 / 32
- Radius: 8 (controls), 14 (header), 50% (avatar)
- Borders: 3px structural, 2px controls
- Type: Cinzel 700 44px; IM Fell English 17px uppercase .16em; Inter 13–14px

## Assets
No new assets. Fonts from Google Fonts (Cinzel, IM Fell English, Inter) — swap for the app's existing display face if one is already loaded. The stone/parchment textures currently in the app can stay; the banner gradient sits over them.

## Files
- `topbar.html` — markup
- `topbar.css` — styles
- `Top Bar Redesign.dc.html` — the full prototype, including the two alternate studies (1b, 1c) that were not chosen
